<?php include APPROOT.'/views/includes/header.php'; ?>
This is the Client Page

<?php include APPROOT . '/views/includes/footer.php'; ?>