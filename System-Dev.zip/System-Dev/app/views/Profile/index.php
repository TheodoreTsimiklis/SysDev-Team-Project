<link rel="stylesheet" href="<?php echo URLROOT; ?>/public/css/login.css">
  <link rel="stylesheet" href="<?php echo URLROOT; ?>/public/css/home.css">
  <link href="<?php echo URLROOT; ?>/css/bootstrap.css" type="text/css" rel="stylesheet" media="all">


<div class="login" style=" height: 100%;
                            width: 100%;
                            background: url('<?php echo URLROOT; ?>/public/images/loginbg.png') no-repeat;
                            background-size: cover;">
    <div class="form">
    <h2 class="h2">Profile Signup <br></h2>
    <br>


      <form method="post" action="" enctype="multipart/form-data">

      <br>
        <div class="form-group">
          <label for="username">Full Name</label>
          <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Full Name">
        </div>
        <br>
        <div class="form-group">
          <label for="username">Phone Number</label>
          <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone Number">
        </div>
        <br>
        <div class="form-group">
          <label for="username">Image URL</label>
          <input type="file" class="form-control" id="image" name="image" placeholder="Enter Image URL">
        </div>
        <br>
        <button  type="submit" name="submit" class="btn btn-primary">Submit</button>
      </form>
  </div>
</div>
