<?php include APPROOT . '/views/includes/header.php'; ?>

<div class="" style="min-height: 100vh;background: url('<?php echo URLROOT; ?>/images/bg.png'); no-repeat center; background-size: cover; ">
    <h1 style="margin-bottom: 15px;padding-top: 30px;text-align: center;"><?php echo ''. $_SESSION['user_email'] .' Profile Information' ?></h1>

    <div class="table-responsive" style=" margin: auto 15rem;">
        <table class="table">
            <?php
            foreach ($data["profiles"] as $profile) {
                echo "<tr><br><br><br>";
              
                echo '<td>
                        <img src="' . URLROOT . '/public/images/' . $profile->image . '" style="width: 500px; height:auto;"
                        
                    </td>';

                echo "<td style='color: #101010; vertical-align: middle;'> <h2>$profile->full_name </h2> <h3 style='color: #101010;'>$profile->phone </h3></td>";

                echo "</tr>";
            }
            ?>
        </table>
    </div>
</div>
<?php include APPROOT . '/views/includes/footer.php'; ?>