<?php include APPROOT . '/views/includes/header.php'; ?>

<div class="" style="min-height: 100vh;background: url('<?php echo URLROOT; ?>/images/profile5.jpg'); no-repeat center; background-size: cover;">
    <h1 style="margin-bottom: 15px;padding-top: 30px;text-align: center;">Profiles</h1>
    <br>

    <div class="table-responsive" style="transform: scale(1);transform-origin: top;opacity: 0.88;filter: contrast(100%); margin: auto 15rem;">
        <table class="table table-bordered" style="font-size:medium;">
            <tr>
                <td style="border-bottom-color: #000000; color: #494949; font-weight: bold; width:50px;" class="text-center">ID</td>
                <td style="border-bottom-color: #000000; color: #494949; font-weight: bold; width:125px;" class="text-center">Full Name</td>
                <td style="border-bottom-color: #000000; color: #494949; font-weight: bold; width:150px;" class="text-center">Email</td>
                <td style="border-bottom-color: #000000; color: #494949; font-weight: bold; width:140px;" class="text-center">Phone Number</td>
                <td style="border-bottom-color: #000000; color: #494949; font-weight: bold; width:200px;" class="text-center">Image</td>
            </tr>
            <?php
            foreach ($data["profiles"] as $profile) {
                echo "<tr>";
                echo "<td style='color: #101010; vertical-align: middle;'>$profile->client_profile_id</td>";
                echo "<td style='color: #101010; vertical-align: middle;'>$profile->full_name</td>";
                echo "<td style='color: #101010; vertical-align: middle;'>$profile->email</td>";
                echo "<td style='color: #101010; vertical-align: middle;'>$profile->phone</td>";
                echo '<td>
                        <div class="d-flex align-items-center"><img src="' . URLROOT . '/public/images/' . $profile->image . '" style="width:23%; height:auto;"
                         </div>
                         </td>';

                echo "</tr>";

            }
                ?>
        </table>
    </div>
        </div>
        <?php include APPROOT . '/views/includes/footer.php'; ?>