<?php

class Profile extends Controller {
    public function __construct()
    {
        $this->profileModel = $this->model('profileModel');
    }

    public function index() {
        //return $this->view('Profile/index');
        if (!isLoggedIn()) {
            echo '<meta http-equiv="refresh" content="0;url=http://localhost/System-Dev/" />';
        } else {
            if (!isset($_POST['submit'])) {
                return $this->view('Profile/index');
            } else {
                $filename= $this->imageUpload();
                $data = [
                    'full_name' => $_POST['full_name'],
                    'phone' => $_POST['phone'],
                    'image' => $filename,
                    'email' => $_SESSION['user_email']
                ];

                if ($this->profileModel->createProfile($data)) {
                    echo '<meta http-equiv="refresh" content="0.5;url=http://localhost/System-Dev/" />';
                } else {

                }
            }
        }
    }

    public function imageUpload(){
        //default value for the picture
        $filename=false;
        
        //save the file that gets sent as a picture
        $file = $_FILES['image'];
        
        $acceptedTypes = ['image/jpeg'=>'jpg',
            'image/gif'=>'gif',
            'image/png'=>'png'];
        //validate the file
        
        if(empty($file['tmp_name']))
            return false;

        $fileData = getimagesize($file['tmp_name']);

        if($fileData!=false && 
            in_array($fileData['mime'],array_keys($acceptedTypes))){

            //save the file to its permanent location
                
            $folder = dirname(APPROOT).'/public/images';
            $filename = uniqid() . '.' . $acceptedTypes[$fileData['mime']];
            move_uploaded_file($file['tmp_name'], "$folder/$filename");
        }
        return $filename;
    }

    
    public function getProfile(){
        $profiles = $this->profileModel->getProfiles();
        $data = [
            "profiles" => $profiles
        ];
        $this->view('Profile/getProfile',$data);
    }


    public function profilePage(){
        $email = $_SESSION['user_email'];
        $profiles = $this->profileModel->getProfileFromAuthor($email);
        $data = [
            "profiles" => $profiles
        ];
        $this->view('Profile/profilePage',$data);
    }
}